<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '# MinifyX

Combine and minify JS and CSS files

- Authors: Patrick Nijkamp <patrick.nijkamp@gmail.com>, Vasily Naumkin <bezumkin@yandex.ru>, Sergey Shlokov <sergant210@bk.ru>
- Current Maintainer: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2

## Features

MinifyX is a MODX Revolution extra that allows to combine and minify JS and CSS
files to speed up your site and reduce server load.

## Installation

MODX Package Management

## Documentation

For more information please read the documentation on https://jako.github.io/MinifyX/

## GitHub Repository

https://github.com/Jako/MinifyX

## Third party licenses

This extra includes third party software, for which we are thankful.

* assetic/framework@v3.2.3 [MIT]
* pear/net_url2@v2.2.2 [BSD-3-Clause]
* pfaciana/tiny-html-minifier@3.0.0 [MIT]
* scssphp/scssphp@v1.13.0 [MIT]
* symfony/deprecation-contracts@v2.5.4 [MIT]
* symfony/polyfill-php80@v1.43.0 [MIT]
* symfony/process@v5.4.54 [MIT]
* wikimedia/less.php@v3.2.1 [Apache-2.0]
* wikimedia/minify@2.7.0 [Apache-2.0]',
    'changelog' => '# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.0] - 2026-11-17

### Added

- Placeholders in the cache path and cache URL settings
- System settings tpl_only, selection_type and selection_range for the plugin

### Changed

- Keep the order of registered assets and process only HTML resources in the plugin
- Cache the combined files of the snippet until a source file changes
- Skip and log missing or unsupported source files

### Fixed

- Fix relative URLs in combined stylesheets and the cache URL
- Fix several issues with registered assets, snippet output and subfolder installations
- Fix clearing the cache on site refresh and keep renamed system settings during an update

## [2.0.7] - 2026-09-03

### Changed

- Fix an uncaught exception when the minified assets file cannot be created or was not changed
- Update Composer dependencies

## [2.0.6] - 2026-04-06

### Changed

- Update the composer dependencies for security reasons (symfony/process from 5.4.47 to 5.4.51)

## [2.0.5] - 2025-05-27

### Fixed

- Rename minifyx.cacheFolder system setting to minifyx.cachePath, which should have been the right setting key since version 2.0

## [2.0.4] - 2025-03-24

### Changed

- Update the composer dependencies for security reasons (symfony/process from 5.4.8 to 5.4.46)

## [2.0.3] - 2022-09-11

### Fixed

- Fix registering scripts and styles in contexts that have a base_url set

## [2.0.2] - 2022-08-15

### Fixed

- Fix removing registered scripts and styles, that don\'t refer an url

## [2.0.1] - 2022-08-03

### Fixed

- Fix not set placeholders by the MinifyX snippet 
- Fix not used minifyJs/minifyCss options by the MinifyX snippet 

### Removed

- Remove not used cacheFolder/cacheUrl properties from the MinifyX snippet 

## [2.0.0] - 2022-06-21

### Changed

- Use Assetic instead of Munee
- Minify HTML with pfaciana/tiny-html-minifier

### Removed

- Complete code refactoring removing internal methods and system settings
- Removed global php method "minify"
- Removed the ability to use versions for assets
- Removed "preHooks" and "hooks"
- Removed image compression with Munee

## [1.7.1] - 2019-03-25

### Fixed

- Fixed bug with startup js register

## [1.7.0] - 2018-12-30

### Added

- Added php function "minify" to manage assets from the php code
- Added the ability to minify content
- Added the ability to use version for assets

### Changed

- Updated composer dependencies

## [1.6.0] - 2018-01-22

### Added

- Added the method "getFileUrl" to the MinifyX class
- Added the method "getFilePath" to the MinifyX class
- Added the "forceUpdate" snippet parameters and the same system setting
- Added the "forceDelete" system setting to delete all files in the cache directory
- Added the "cssTpl" and "jsTpl" snippet parameters
- Added new register type "print" for immediate output
- Added the file hook "fixVm.php" which fixes the "vmax" and "vmin" units after css compilation

### Changed

- Updated all Munee dependencies. You can do it anytime via composer
- Php version must be >= 5.6

### Fixed

- Some bugfixes

## [1.5.0] - 2018-01-19

### Added

- Added config file for groups (core/components/minifyx/config/groups.php)
- Added the "cssGroup" snippet parameter
- Added the "jsGroup" snippet parameter
- Added the "preHooks" snippet parameter. A hook can be either a snippet or a file, specified in the core/components/minifyx/hooks folder
- Added the "hooks" snippet parameter. A hook can be either a snippet or a file, specified in the core/components/minifyx/hooks folder
- Added the ability to run the snippet multiple times
- Added file hook "cssToPage.php" (&hooks=`cssToPage.php`)

## [1.4.4] - 2016-05-16

### Changed

- [#22] Updated sabberworm/php-css-parser to version 7.0.3

## [1.4.3] - 2016-04-28

### Changed

- [#21] Updated sabberworm/php-css-parser to version 7.0.2

## [1.4.2] - 2015-08-22

### Changed

- Updated Munee with all subpackages

### Fixed

- Fixed fatal error on PHP 5.3.3

## [1.4.1] - 2015-06-01

### Changed

- Updated Munee with all subpackages
- [#18] Improved work of plugin

## [1.3.1] - 2014-07-21

### Changed

- [#12] Support of MODX 2.3
- [#11] Improved set of "munee_cache" variable on Windows

## [1.3.0-pl1] - 2014-05-12

### Changed

- [#2] Added cut of comments in raw styles and scripts
- [#9] Changed lessphp to https://github.com/oyejorge/less.php
- Updated scssphp to version 0.0.10

### Fixed

- [#8] Fixed determining of cache dir for advanced site configuration
- [#7] Fixed clearing cache

## [1.3.0-b] - 2013-12-26

### Added

- Added plugin MinifyX that can process scripts, styles and images of web page

### Changed

- Refactored main class
- Rewrited snippet MinifyX
- Changed cached files format
- Improved connector in assets for image processing

## [1.2.2-pl3] - 2013-12-16

### Removed

- Removed phar file

### Fixed

- Fixed url of cache dir in subfolder installations
- Ability of commenting files by prefixing them by the dash

## [1.2.1] - 2013-12-03

### Fixed

- [#1] Replaced constant DIRECTORY_SEPARATOR to \'/\'

## [1.2.0] - 2013-11-23

### Fixed

- Fixed clean of parameter &cacheFolder

## [1.2.0-rc] - 2013-11-20

### Changed

- Updated leafo/lessphp to v0.4.0
- Updated leafo/scssphp to v0.0.8
- Improved error logging

## [1.2.0-b] - 2013-11-12

### Added

- Integrated Munee library from http://mun.ee
- Auto creation of cache dir
- More options to register files on frontend

## [1.1.3] - 2013-01-07

### Changed

- Absolute path in the URL attribute of all compressed files

## [1.1.2] - 2012-09-11

### Changed

- Improved caching of minified files

## [1.1.1] - 2012-09-10

### Fixed

- Removed E_WARNING on line 94 of minifyx.class.php

## [1.1.0] - 2012-09-09

### Added

- Added Douglas Crockford\'s JSMin https://github.com/rgrove/jsmin-php/
- Added properties to snippet
- Added parameters jsFilename && cssFilename

### Changed

- Changed css minifier to Minify_CSS_Compressor from https://code.google.com/p/minify/
- Serious refactor of code
- Improved caching of files

### Removed

- Removed plugin

## [1.0.0] - 2012-03-26

### Added

- Initial Version
',
    'setup-options' => 'minifyx-2.1.0-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=2.8',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c969cfd40bee517b60b8c8f7b8d0e509',
      'native_key' => 'minifyx',
      'filename' => 'modNamespace/cdabffa12fc26163d045010661261ccf.vehicle',
      'namespace' => 'minifyx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43f41f4efbe6c7c4b2670a9208afdca4',
      'native_key' => 'minifyx.debug',
      'filename' => 'modSystemSetting/8ce1185bbf0f0ba8124ae088c4cc7780.vehicle',
      'namespace' => 'minifyx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6f6c981026a4eea1eaf1c9707498ff5',
      'native_key' => 'minifyx.processRegistered',
      'filename' => 'modSystemSetting/c84051fd8ee6882e6753848ad2792540.vehicle',
      'namespace' => 'minifyx',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ade668c922cf9e1aa3ebf83c461d926a',
      'native_key' => 'minifyx.excludeRegistered',
      'filename' => 'modSystemSetting/5c56c9df9a934b860ecf84caa923a78c.vehicle',
      'namespace' => 'minifyx',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ea31f03db037df6076949d9fd0ddbbe',
      'native_key' => 'minifyx.minifyJs',
      'filename' => 'modSystemSetting/e034086d487dbcaeec562efecf52065b.vehicle',
      'namespace' => 'minifyx',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be0fadedaf1c51e82a9b8795e3dabb76',
      'native_key' => 'minifyx.minifyCss',
      'filename' => 'modSystemSetting/54c50d5eb59d833e26138d9aae41102d.vehicle',
      'namespace' => 'minifyx',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7e38391e318c59533e4dcf388f9b0a7',
      'native_key' => 'minifyx.jsFilename',
      'filename' => 'modSystemSetting/13602f23920bbdc1f4fe84e6b1dadaf0.vehicle',
      'namespace' => 'minifyx',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e75aa4f493c173e888cdd95b6e0422ae',
      'native_key' => 'minifyx.cssFilename',
      'filename' => 'modSystemSetting/f0e3dc22ef3d4a7f977d8eaa7fdcb4d3.vehicle',
      'namespace' => 'minifyx',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80f966d36d8f68732821ca37b47add8b',
      'native_key' => 'minifyx.jsTpl',
      'filename' => 'modSystemSetting/f19e681d29f7f60c69ddd8ad93de2a57.vehicle',
      'namespace' => 'minifyx',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c3d1eb067374ef5dff14f0a629f2cfa',
      'native_key' => 'minifyx.cssTpl',
      'filename' => 'modSystemSetting/d3200ecdb6bff374d3b140a98817abc0.vehicle',
      'namespace' => 'minifyx',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94ef01ceb355822aa3770b6b1cfdc30a',
      'native_key' => 'minifyx.cachePath',
      'filename' => 'modSystemSetting/ba96a2fed0310b051f8a9e34a88ee265.vehicle',
      'namespace' => 'minifyx',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dafb5086ffff5b88f8d85ed0c008490a',
      'native_key' => 'minifyx.cacheUrl',
      'filename' => 'modSystemSetting/fd6f7d95e980b642fe6dc6f2a5b231a6.vehicle',
      'namespace' => 'minifyx',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cad1e17c51455191e9373f6ce1912e4',
      'native_key' => 'minifyx.minifyHtml',
      'filename' => 'modSystemSetting/b206dfb10ee8c57e3ec18e93ab88a316.vehicle',
      'namespace' => 'minifyx',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43c92a7f61f1a5cf2d3dee4edafd01ad',
      'native_key' => 'minifyx.tpl_only',
      'filename' => 'modSystemSetting/0bfc81a432cc256aadb672a483344502.vehicle',
      'namespace' => 'minifyx',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7380430981d5eba809e6b7055c499be',
      'native_key' => 'minifyx.selection_type',
      'filename' => 'modSystemSetting/e63d9713b277b4bad0d05f54a8c9727e.vehicle',
      'namespace' => 'minifyx',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1aa1edd1eb121dd0f70ea15c9ac6112',
      'native_key' => 'minifyx.selection_range',
      'filename' => 'modSystemSetting/5c17c0cb35f9f0b65f90f28e93890fef.vehicle',
      'namespace' => 'minifyx',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3e4cacfdb9620467743b3df8ac0706ff',
      'native_key' => NULL,
      'filename' => 'modCategory/adc8c962d1d87c2204c9ec2ba941466b.vehicle',
      'namespace' => 'minifyx',
    ),
  ),
);