<?php
/**
 * @package minifyx
 * @subpackage plugin
 */

namespace TreehillStudio\MinifyX\Plugins\Events;

use TreehillStudio\MinifyX\Plugins\Plugin;
use xPDO;

class OnSiteRefresh extends Plugin
{
    /**
     * The resource selection settings must not prevent clearing the cache.
     *
     * {@inheritDoc}
     */
    public function init(): bool
    {
        return true;
    }

    public function process()
    {
        if (!$this->minifyx->prepareCachePath()) {
            $this->modx->log(xPDO::LOG_LEVEL_ERROR, 'Could not create cache dir "' . $this->minifyx->getOption('cachePath') . '"', '', $this->minifyx->packageName);
        }
        $this->minifyx->clearAssetFiles();
        $this->modx->log(xPDO::LOG_LEVEL_INFO, $this->modx->lexicon('minifyx.refresh_cache', [
            'packagename' => $this->minifyx->packageName
        ]));
    }
}
