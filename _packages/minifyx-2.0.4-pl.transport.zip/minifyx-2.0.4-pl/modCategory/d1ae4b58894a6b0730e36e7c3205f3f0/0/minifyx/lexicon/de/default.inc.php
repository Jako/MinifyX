<?php
/**
 * Default Lexicon Entries for MinifyX
 *
 * @package minifyx
 * @subpackage lexicon
 */
$_lang['minifyx'] = 'MinifyX';
$_lang['minifyx.refresh_cache'] = 'Löschen des [[+packagename]]-Caches';
